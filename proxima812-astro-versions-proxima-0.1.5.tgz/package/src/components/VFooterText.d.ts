/// <reference types="astro/client" />

import type { AstroComponentFactory } from "astro/runtime/server/index.js";

declare const VFooterText: AstroComponentFactory;
export default VFooterText;
